$(document).ready(function(){
    $(".dropdown").click(function(){
			$("#myDropdown").toggle();
		});
    
    
	$("#myInput").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#searchlist li").filter(function() {
			$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	});
	var myPieChart;
	$(".listContent").click(function(){
        $("#testcasename").html("");
        $("#status").html("");
        $("#sectionShow").hide();
        $("#sectionContent").hide();
		var id = $(this).attr("id");
		var value = $(this).val();
        var newDiv=[];
        var newcontent=[];
		console.log("VALUE : " + value);
		$.ajax({
				url: "/"+id,
				type :"POST",
				data : {id:value,para:id},
				dataType:"json",
				success : function(resData){
                    
					$("#sectionShow").show();
					$("#sectionContent").show();
					$("#contentName").html(resData.name);
					$("#contentPassed").html(resData.passed);
					$("#contentId").html(resData.id);
					$("#contentTestsetname").html(resData.testsetname);
					$("#contentRuntime").html(resData.runtime);
					$("#contentFailed").html(resData.failed);
					$("#contentTotal").html(resData.total);
					$("#contentNotrun").html(resData.notRun);
					$("#contentUser").html(resData.user);
					$("#contentLastrundate").html(resData.lastRunDate);
                   
					for(var i=0;i<resData.testCaseName.length;i++){
                       var testcasename = document.createElement("P");
                       var status = document.createElement("P");
                        testcasename.id= resData.testCaseName[i];
                        status.id= resData.testCaseName[i];
                        var tc = document.createTextNode(resData.testCaseName[i]);
                        var stat = document.createTextNode(resData.status[i]);
                        testcasename.appendChild(tc);
                        status.appendChild(stat);
                        document.getElementById("testcasename").appendChild(testcasename);
                        document.getElementById("status").appendChild(status);
                    }
                    console.log(resData.testCaseName);
					var brandPrimary = '#33b35a';
					var PIECHART = $('#pieChart');
                   
					if(myPieChart!=null){
						myPieChart.destroy();
					}
					myPieChart = new Chart(PIECHART, {
						type: 'doughnut',
						data: {
							labels: [
								"Passed",
								"Failed",
								"No Run"
							],
							
						datasets: [
						{
							data: [resData.passed,resData.failed,resData.notRun],
							borderWidth: [1, 1, 1],
							backgroundColor: [
							brandPrimary,
							"#dc3545",
							"#ffc107"
							]
							}]
						}
					});
				
				
				}
			});
			
			
	});
	//-------------------------------------------------------------------
			//PIE CHART STARTS
	//-------------------------------------------------------------------
	
	//-------------------------------------------------------------------
				//PIE CHART ENDS
	//-------------------------------------------------------------------
	
	

}); //end of document file