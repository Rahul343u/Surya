var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var path = require('path');
//var userData = require('./Public/js/data');
var MongoClient = require('mongodb').MongoClient;
var mongoDB = "mongodb://10.13.66.82:27017/automationframework";
var port = 3004;

app.use(express.static('Public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');


app.get('/report',function(req,res){
	MongoClient.connect(mongoDB, function(err, db) {
					if (err) throw err;
					console.log('connected to database' + mongoDB);

					db.collection("executions").find({}).toArray(function(err, executions)
					{
                        if(err){
						console.log(err);
						}
						else {
							var itms=[];
                            var id=[];
                            var total=[];
							for(i=0;i<executions.length;i++){
								id[i] = executions[i]._id;
                                itms[i] = executions[i].name;
                                total[i]=executions[i].total;
								if(i==executions.length-1){
                                    
									res.render('sidebar',{itms : itms,total : total,id: id,divcss: 'display:none;'});
								}
							}
							//console.log(id);
						}
					});
					
  
	});
	
});

app.post('/:id',function(req,res){
	var val = req.body.id;
    var para = req.body.para;
	//console.log("Parameter "+para);
	MongoClient.connect(mongoDB, function(err, db) {
					if (err) throw err;
					

					db.collection("executions").find({_id:para}).toArray(function(err, executions)
					{
						if(err){
						console.log(err);
						}
						else {
                            
                            var name;
							var passed;
							var id;
							var testsetname;
							var runtime;
							var failed;
							var total;
							var notRun;
							var user;
							var lastRunDate;
							var all=executions[0];
                            var testCaseName=[];
                            var status=[];
                            
                            
                            db.collection("executiontestcases").find({executionID:para}).toArray(function(err, executiontc)
					       {
						      if(err){
						          console.log(err);
						      }
						      else {
                             
                                  var testCaseName=[];
							         var status=[];
							     for(var i=0;i<executiontc.length;i++){
                                testCaseName[i]=executiontc[i].name;
                                status[i]=executiontc[i].status;
                                     
                                if(i==executions.length-1){
                                    
                                   
                                };
                            }
                             res.send({name : all.name,
										passed : all.passed,
										id : all._id,
										testsetname : all.testsetname,
										runtime : all.runtime,
										failed : all.failed,
										total : all.total,
										notRun : all.notRun,
										user : all.user,
										lastRunDate : all.lastRunDate,
                                        testCaseName : testCaseName,
                                        status : status,
                                        divcss : 'display:block;'});
                        }
                        
					});
                            
            
                           		
                        }
					});
        	});
	
});
	
	
	/*console.log(executions);
	userData.find({},function(err,testDetails){
		if(err){
			console.log(err.stack);
		}else if(!testDetails){
			console.log('No Data Found');
		}else{
			
			console.log(testDetails.name);
		}
	});*/
	



app.listen(port, function (err) {
  console.log('Server is running on port:', port);
});
